<%@page import="com.helper.*"%>
<%@page import="com.entity.*"%>
<%@page import="java.util.List"%>

<%
DatabaseClass DAO = new DatabaseClass();
String pageParam = request.getParameter("page");
%>

<%

/* ====================== ADD NEW USER ========================== */
if ("NewUser".equals(pageParam)) {

    String username = request.getParameter("username");
    String email = request.getParameter("email");
    String phone_no = request.getParameter("phone_no");
    String password = request.getParameter("password");

    if (DAO.UserValidate(email)) {

        // skipping OTP complexity for now (to avoid bugs)
        User user = new User();
        user.setId(RandomIdGenerator.generateRandomString());
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone_no(phone_no);
        user.setCreated_Date(DateFormat.getCurrentDate());

        if (DAO.saveUser(user)) {
            response.sendRedirect("User-Login.jsp?msg=successfully");
        } else {
            response.sendRedirect("User-Login.jsp?msg=unsuccessfully");
        }

    } else {
        response.sendRedirect("User-Login.jsp?msg=Already");
    }
}


/* ====================== USER LOGIN ========================== */
else if ("LoginUser".equals(pageParam)) {

    String email = request.getParameter("email");
    String password = request.getParameter("password");

    if (DAO.UserLoginValidate(email, password)) {

        session.setAttribute("UserStatus", "1");
        session.setAttribute("UserId", DAO.getUserId(email, password));

        // ✅ FIXED (redirect)
        response.sendRedirect("User-Page.jsp?pg=1");

    } else {

        // ✅ FIXED (redirect)
        response.sendRedirect("User-Login.jsp?msg=unsuccessfully1");
    }
}


/* ====================== STUDENT LOGIN ========================== */
else if ("LoginStudent".equals(pageParam)) {

    String email = request.getParameter("email");
    String password = request.getParameter("password");

    if (DAO.studLoginValidate(email, password)) {

        session.setAttribute("studStatus", "1");
        session.setAttribute("studId", DAO.getstudId(email, password));

        // ✅ FIXED
        response.sendRedirect("stud-Page.jsp?spg=1");

    } else {

        // ✅ FIXED
        response.sendRedirect("Student-Login.jsp?msg=unsuccessfully1");
    }
}


/* ====================== LOGOUT USER ========================== */
else if ("logout1".equals(pageParam)) {

    session.setAttribute("UserStatus", "0");
    session.removeAttribute("UserId");

    response.sendRedirect("index.jsp");
}


/* ====================== LOGOUT STUDENT ========================== */
else if ("logout".equals(pageParam)) {

    session.setAttribute("studStatus", "0");
    session.removeAttribute("studId");

    response.sendRedirect("index.jsp");
}

%>